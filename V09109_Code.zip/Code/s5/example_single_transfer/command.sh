#!/usr/bin/env bash
python3 INetwork.py images/inputs/content/Japanese-cherry-widescreen-wallpaper-Picture-1366x768.jpg \
                    fresh-orange-iii-torrie-smiley.jpg \
                    single_transfer \
                    --num_iter 20
