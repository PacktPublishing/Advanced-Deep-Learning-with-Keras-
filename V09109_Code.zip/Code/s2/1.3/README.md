# Visualize your training in real time

```
pip3 install -r requirements.txt
python3 hualos/api.py # start the frontend server.

# in another terminal just start the training by running this script:
python3 model.py
```

Now visualize the training in realtime at:
```
http://localhost:9000/
```
