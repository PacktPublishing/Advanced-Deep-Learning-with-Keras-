# Regularization

- Dropout
- L1, L2
- Batch Norm
- Early Stopping

Visualize the activations of your Keras here: https://github.com/philipperemy/keras-visualize-activations
