wget https://www.kaggle.com/c/dogs-vs-cats/download/train.zip
wget https://www.kaggle.com/c/dogs-vs-cats/download/test1.zip
